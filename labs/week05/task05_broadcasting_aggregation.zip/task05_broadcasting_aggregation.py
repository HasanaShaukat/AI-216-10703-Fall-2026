import numpy as np

features = np.array([
    [10.0, 100.0, 1.0],
    [20.0, 200.0, 2.0],
    [30.0, 300.0, 3.0],
    [40.0, 400.0, 4.0]
])

overall_mean = features.mean()
column_means = features.mean(axis=0)
row_means = features.mean(axis=1)
column_minimums = features.min(axis=0)
column_maximums = features.max(axis=0)

print("Overall mean:", overall_mean, "shape:", np.shape(overall_mean))
print("Column means:", column_means, "shape:", column_means.shape)
print("Row means:", row_means, "shape:", row_means.shape)
print("Column minimums:", column_minimums, "shape:", column_minimums.shape)
print("Column maximums:", column_maximums, "shape:", column_maximums.shape)

centered = features - column_means
print("\nCentered matrix:\n", centered)
print("Centered shape:", centered.shape)
print("Centered column means:", centered.mean(axis=0))

factors = np.array([1.0, 0.01, 10.0])
adjusted_features = features * factors
print("\nColumn-scaled matrix:\n", adjusted_features)
print("The three factors match the three columns and broadcast across all rows.")

row_offsets = np.array([1.0, 2.0, 3.0, 4.0])
try:
    print(features + row_offsets)
except ValueError as error:
    print("\nDirect addition fails because (4, 3) and (4,) are incompatible:", error)

reshaped_offsets = row_offsets.reshape(4, 1)
result = features + reshaped_offsets
print("\nReshaped offsets:\n", result)
print("Result shape:", result.shape)
print("A (4, 1) array broadcasts one offset to each row.")
