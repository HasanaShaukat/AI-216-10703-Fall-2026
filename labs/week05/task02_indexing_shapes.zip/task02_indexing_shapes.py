import numpy as np

sensor_features = np.array([
    [20.0, 45.0, 0.30],
    [24.0, 52.0, 0.55],
    [27.0, 61.0, 0.70],
    [30.0, 72.0, 0.85]
])

print("Shape:", sensor_features.shape)
print("Dimensions:", sensor_features.ndim)
print("Size:", sensor_features.size)
print("Data type:", sensor_features.dtype)
print("Rows are observations; columns are temperature, humidity, and vibration.")

print("\nFirst observation:", sensor_features[0])
print("Final vibration score:", sensor_features[-1, 2])
print("All temperatures:", sensor_features[:, 0])
print("Humidity column:\n", sensor_features[:, 1:2])
print("First three observations:\n", sensor_features[:3])
print("Last two feature columns:\n", sensor_features[:, 1:])

values = np.arange(1, 13)
print("\nValues reshaped to (4, 3):\n", values.reshape(4, 3))

single_feature = np.array([10, 20, 30, 40])
column_feature = single_feature.reshape(4, 1)
print("Original shape:", single_feature.shape)
print("Column shape:", column_feature.shape)
print(column_feature)

print("\nThinking questions")
print("sensor_features[:, 0] selects every row from the first column.")
print("[:, 1] returns a one-dimensional column; [:, 1:2] keeps it two-dimensional.")
print("Some ML operations expect a two-dimensional column with shape (4, 1).")
