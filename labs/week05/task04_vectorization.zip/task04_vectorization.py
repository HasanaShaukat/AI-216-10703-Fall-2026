import numpy as np

temperatures_c = [0.0, 10.0, 22.5, 30.0, 40.0]

fahrenheit_loop = []
for temperature in temperatures_c:
    fahrenheit_loop.append((temperature * 9 / 5) + 32)

temperatures_array = np.array(temperatures_c)
fahrenheit_numpy = (temperatures_array * 9 / 5) + 32

print("Fahrenheit using a loop:", fahrenheit_loop)
print("Fahrenheit using NumPy:", fahrenheit_numpy)
print("Results equivalent:", np.allclose(fahrenheit_loop, fahrenheit_numpy))

base_scores = np.array([0.70, 0.82, 0.91, 0.77])
score_adjustments = np.array([0.03, -0.02, 0.01, 0.05])
adjusted_scores = base_scores + score_adjustments
print("\nAdjusted scores:", adjusted_scores)
print("Minimum:", adjusted_scores.min())
print("Maximum:", adjusted_scores.max())
print("Average:", adjusted_scores.mean())

pixels = np.array([0, 64, 128, 255], dtype=np.uint8)
pixels_float = pixels.astype(float)
scaled_pixels = pixels_float / 255
print("\nOriginal pixel dtype:", pixels.dtype)
print("Scaled pixels:", scaled_pixels)
print("Scaled dtype:", scaled_pixels.dtype)

print("\nThinking questions")
print("Vectorization replaces the explicit loop for the NumPy calculation.")
print("A suitable dtype helps prevent unwanted rounding or overflow.")
print("NumPy is not automatically faster for every tiny or non-numerical task.")
