import numpy as np


def clean_sensor_rows(readings):
    readings = np.asarray(readings, dtype=float)
    if readings.ndim != 2 or readings.shape[1] != 3:
        raise ValueError("readings must be a two-dimensional array with 3 columns")

    valid_mask = (
        (readings[:, 0] >= 0) & (readings[:, 0] <= 50) &
        (readings[:, 1] >= 0) & (readings[:, 1] <= 100) &
        (readings[:, 2] >= 0) & (readings[:, 2] <= 1)
    )
    return readings[valid_mask].copy()


def summarize_features(readings):
    readings = np.asarray(readings, dtype=float)
    if readings.ndim != 2 or readings.shape[1] != 3:
        raise ValueError("readings must be a two-dimensional array with 3 columns")
    if readings.shape[0] == 0:
        raise ValueError("Cannot summarize an empty dataset")

    return {
        "mean": readings.mean(axis=0),
        "minimum": readings.min(axis=0),
        "maximum": readings.max(axis=0)
    }


def minmax_scale(readings):
    readings = np.asarray(readings, dtype=float)
    if readings.ndim != 2 or readings.shape[1] != 3:
        raise ValueError("readings must be a two-dimensional array with 3 columns")
    if readings.shape[0] == 0:
        raise ValueError("Cannot scale an empty dataset")

    minimums = readings.min(axis=0)
    maximums = readings.max(axis=0)
    spans = maximums - minimums
    safe_spans = np.where(spans == 0, 1, spans)
    scaled = (readings - minimums) / safe_spans
    scaled[:, spans == 0] = 0.0
    return scaled


def flag_for_review(readings):
    readings = np.asarray(readings, dtype=float)
    if readings.ndim != 2 or readings.shape[1] != 3:
        raise ValueError("readings must be a two-dimensional array with 3 columns")
    return (readings[:, 0] > 27) | (readings[:, 2] >= 0.70)
