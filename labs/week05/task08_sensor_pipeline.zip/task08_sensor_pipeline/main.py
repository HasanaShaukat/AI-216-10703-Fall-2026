import numpy as np
from sensor_utils import clean_sensor_rows, summarize_features, minmax_scale, flag_for_review

raw_sensor_data = np.array([
    [21.0, 42.0, 0.30],
    [24.0, 51.0, 0.55],
    [-10.0, 40.0, 0.45],
    [26.0, 68.0, 0.80],
    [32.0, 110.0, 0.95],
    [28.0, 59.0, 0.72],
    [23.0, 48.0, -0.20],
    [30.0, 74.0, 1.00]
], dtype=float)

cleaned_data = clean_sensor_rows(raw_sensor_data)
summary = summarize_features(cleaned_data)
scaled_data = minmax_scale(cleaned_data)
review_flags = flag_for_review(cleaned_data)

total_readings = raw_sensor_data.shape[0]
valid_readings = cleaned_data.shape[0]
invalid_readings = total_readings - valid_readings

print("Raw data shape:", raw_sensor_data.shape)
print("Cleaned data shape:", cleaned_data.shape)
print("\nSummary")
print("Total readings:", total_readings)
print("Valid readings:", valid_readings)
print("Invalid readings:", invalid_readings)
print("Rows flagged for review:", int(review_flags.sum()))
print("Feature means:", summary["mean"])
print("\nScaled data:\n", scaled_data)
print("Scaled data shape:", scaled_data.shape)
