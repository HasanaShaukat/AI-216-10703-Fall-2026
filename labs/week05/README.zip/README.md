# Lab 05 — NumPy & Numerical Computing for AI

## Environment
- Python 3
- NumPy (`python -m pip install numpy`)

## Tasks
1. Array basics
2. Indexing, shapes, and reshaping
3. Views and copies
4. Vectorization and data types
5. Broadcasting and aggregation
6. Boolean masks and conditions
7. Feature scaling and weighted scores
8. Sensor feature preparation pipeline

## Important shape examples
- `sensor_features` has shape `(4, 3)`: four observations and three features.
- `sensor_features[:, 0]` has shape `(4,)`; `sensor_features[:, 1:2]` has shape `(4, 1)`.
- `features.mean(axis=0)` has shape `(3,)`, one mean per feature.
- The cleaned sensor data has shape `(5, 3)`.

## Views and copies
`b = a` makes another name for the same array. `b = a[:3]` normally creates a view, so modifying it can affect the original. `b = a[:3].copy()` creates independent data.

## Vectorization
The Fahrenheit task uses a NumPy expression to transform all values without an explicit Python loop. `np.allclose()` checks that the loop and NumPy results are numerically equivalent.

## Sensor pipeline design
- `clean_sensor_rows()` validates all three features with one Boolean mask and returns a copy of valid rows.
- `summarize_features()` returns feature-wise mean, minimum, and maximum.
- `minmax_scale()` scales each feature column and assigns 0.0 to a constant feature to avoid division by zero.
- `flag_for_review()` flags a row if temperature is above 27 or vibration is at least 0.70.
- Empty input is rejected by summary and scaling functions because those calculations need rows to produce meaningful results.
- Raw input is kept unchanged so results can be reproduced and checked.

## Testing and numerical checks
The supplied sensor dataset should produce:
- Raw shape: `(8, 3)`
- Cleaned shape: `(5, 3)`
- Invalid rows: `3`
- Review flags: `3`
- Scaled shape: `(5, 3)`

## AI Usage Log
### Tool Used
ChatGPT

### What I Asked
Help prepare beginner-friendly solutions for the NumPy lab tasks.

### What I Used
Used the solutions as a reference for the required NumPy operations and project structure.

### What I Verified or Changed Myself
Run each script, compare its output with the lab's expected shapes and counts, and make any changes needed after understanding the code.

## Run the tasks
From the folder containing `labs`:
`python labs/week05/task01_array_basics.py`

For the pipeline:
`python labs/week05/task08_sensor_pipeline/main.py`
