import numpy as np

confidence_scores = np.array([0.94, 0.79, -0.10, 0.88, 1.20, 0.63, 0.81])

valid_mask = (confidence_scores >= 0) & (confidence_scores <= 1)
valid_scores = confidence_scores[valid_mask]
invalid_count = np.count_nonzero(~valid_mask)

labels = np.where(valid_scores < 0.80, "review", "accepted")
accepted_count = np.count_nonzero(labels == "accepted")
review_count = np.count_nonzero(labels == "review")
accepted_share = accepted_count / valid_scores.size if valid_scores.size else 0.0

print("Validity mask:", valid_mask)
print("Valid scores:", valid_scores)
print("Invalid-value count:", invalid_count)
print("Number of valid scores:", valid_scores.size)
print("Review labels:", labels)
print("Mean valid confidence:", valid_scores.mean() if valid_scores.size else "No valid scores")
print("Accepted count:", accepted_count)
print("Review count:", review_count)
print("Accepted share:", accepted_share)

boundary_values = np.array([0.0, 0.80, 1.0, -0.01, 1.01])
boundary_mask = (boundary_values >= 0) & (boundary_values <= 1)
print("\nBoundary values:", boundary_values)
print("Boundary validity:", boundary_mask)
print("Exactly 0.0 and 1.0 are valid; 0.80 is valid and accepted.")
