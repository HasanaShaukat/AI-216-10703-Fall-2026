import numpy as np

readings = np.array([10, 20, 30, 40, 50])
first_three = readings[:3]
first_three[0] = 99
print("Part A - slice view:", first_three)
print("Original after view change:", readings)

readings = np.array([10, 20, 30, 40, 50])
first_three_copy = readings[:3].copy()
first_three_copy[0] = 99
print("\nPart B - independent copy:", first_three_copy)
print("Original after copy change:", readings)

matrix = np.array([
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
])

matrix_view = matrix[:2, :]
matrix_view[0, 0] = 100
print("\nPart C - matrix after changing view:\n", matrix)

matrix = np.array([
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
])
matrix_copy = matrix[:2, :].copy()
matrix_copy[0, 0] = 100
print("Matrix copy after change:\n", matrix_copy)
print("Original matrix remains:\n", matrix)

print("\nREADME explanation:")
print("b = a makes b another name for the same array.")
print("b = a[:3] usually creates a view, so changes can affect a.")
print("b = a[:3].copy() creates independent data, so changes do not affect a.")
