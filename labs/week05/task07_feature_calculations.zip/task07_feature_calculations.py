import numpy as np

feature_matrix = np.array([
    [10.0, 100.0, 5.0],
    [20.0, 150.0, 5.0],
    [30.0, 200.0, 5.0],
    [40.0, 250.0, 5.0]
])

column_minimums = feature_matrix.min(axis=0)
column_maximums = feature_matrix.max(axis=0)
column_spans = column_maximums - column_minimums

safe_spans = np.where(column_spans == 0, 1, column_spans)
scaled_features = (feature_matrix - column_minimums) / safe_spans
scaled_features[:, column_spans == 0] = 0.0

print("Column minimums:", column_minimums)
print("Column maximums:", column_maximums)
print("Column spans:", column_spans)
print("Scaled matrix:\n", scaled_features)
print("Same shape:", scaled_features.shape == feature_matrix.shape)
print("All values finite:", np.isfinite(scaled_features).all())
print("The constant feature is set to 0.0 because its range is zero.")

features = np.array([
    [1.0, 2.0],
    [2.0, 3.0],
    [3.0, 4.0]
])
weights = np.array([0.4, 0.6])
bias = 0.5

weighted_scores = features @ weights + bias
print("\nWeighted scores:", weighted_scores)
print("Weighted score shape:", weighted_scores.shape)
print("The @ operator combines each row with weights into one score; * multiplies element by element.")
