import time
import numpy as np

values_list = list(range(200_000))
values_array = np.array(values_list, dtype=float)

start = time.perf_counter()
list_result = [value * 2 for value in values_list]
list_time = time.perf_counter() - start

start = time.perf_counter()
array_result = values_array * 2
numpy_time = time.perf_counter() - start

print("List comprehension time:", list_time)
print("NumPy operation time:", numpy_time)
print("Equivalent results:", np.allclose(list_result, array_result))
print("NumPy array creation was not included in the timings.")
print("Timing varies by computer and run; this is only a small benchmark.")
