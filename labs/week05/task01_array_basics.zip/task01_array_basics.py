import numpy as np

scores_list = [65, 75, 85, 95]
scores_array = np.array(scores_list)

print("List + List:", scores_list + scores_list)
print("Array + Array:", scores_array + scores_array)
print("Scores plus 5:", scores_array + 5)

print("\nArray information")
print("Values:", scores_array)
print("Type:", type(scores_array))
print("Shape:", scores_array.shape)
print("Dimensions:", scores_array.ndim)
print("Size:", scores_array.size)
print("Data type:", scores_array.dtype)

print("\nCreating arrays")
print("Zeros:", np.zeros(5))
print("Ones:", np.ones(5))
print("Even numbers:", np.arange(2, 11, 2))
print("Five values from 0 to 1:", np.linspace(0, 1, 5))

print("\nThinking questions")
print("Lists join together with +, while NumPy arrays add corresponding values.")
print("Shape (4,) means a one-dimensional array with four values.")
print("Lists are useful for mixed data types and general-purpose collections.")
